#include "system.h"

void rising_edge_detector(void);
char switch_state_detector(void);

unsigned char *buttonsBase_ptr  = (unsigned char *) BUTTONS_BASE;
unsigned char *switchesBase_ptr = (unsigned char *) SWITCHES_BASE;

int main(void)
{
	unsigned char *hexBase_ptr      = (unsigned char *) HEX0_BASE;
	unsigned char hex_displays[10] = {0b01000000, 0b01111001, 0b00100100, 0b00110000, 0b00011001, 0b00010010, 0b00000010, 0b01111000, 0b00000000, 0b00010000};
	unsigned char i = 0;
	unsigned char inc_or_dec;
	
	*hexBase_ptr = hex_displays[i];
	
	while(1)
	{
		rising_edge_detector();
		inc_or_dec = switch_state_detector();
		
		if(inc_or_dec == 1)
		{
			if(i == 9)
				i = 0;
			else
				i++;
		}
		else
		{
			if(i == 0)
				i = 9;
			else
				i--;
		}
		*hexBase_ptr = hex_displays[i];
	}
}

void rising_edge_detector(void)
{
	char detected = 0;
	char engaged  = 0;
	unsigned char buttons_val;
	
	while(engaged == 0)
	{
		buttons_val = *buttonsBase_ptr;
		buttons_val = buttons_val % 2;
		if(buttons_val == 0)
			engaged = 1;
	}
	
	while(detected == 0)
	{
		buttons_val = *buttonsBase_ptr;
		buttons_val = buttons_val % 2;
		if(buttons_val == 1)
			detected = 1;
	}
	
	return;
}

char switch_state_detector(void)
{
	unsigned char switch_val;
	unsigned char inc_or_dec; // Tells main to increment or decrement the counter.  1 = inc, 0 = dec
	
	switch_val = *switchesBase_ptr;
	switch_val = switch_val % 2;
	if(switch_val == 1)
		inc_or_dec = 1;
	else
		inc_or_dec = 0;
	
	return inc_or_dec;
}
	